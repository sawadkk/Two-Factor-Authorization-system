from django.apps import AppConfig


class BasketConfig(AppConfig):
    name = 'basket'
